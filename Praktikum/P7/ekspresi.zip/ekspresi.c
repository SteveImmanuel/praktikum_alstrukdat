/*  NIM		: 13517039
    Nama	: Steve Andreas Immanuel
    Tanggal	: 18/10/18
    Topik praktikum	: Stack
    Deskripsi 
    */

#include <stdio.h>
#include <string.h>
#include "stackt.h"
#include "boolean.h"
#include "mesintoken.h"
#include <math.h>

int main(){
	Stack tampung;
	int bil1,bil2,hasil;
	CreateEmpty(&tampung);
	STARTTOKEN();
	if(!EndToken){
		while(!EndToken){
				//printf("char=%c val=%d\n",CToken.tkn,CToken.val);
				if(CToken.tkn=='b'){
					Push(&tampung,CToken.val);
					printf("%d\n",CToken.val);
				}else{
					Pop(&tampung,&bil2);
					Pop(&tampung,&bil1);
					switch(CToken.tkn){
						case '+' :
							hasil=bil1+bil2;
							break;
						case '-' :
							hasil=bil1-bil2;
							break;
						case '*' :
							hasil=bil1*bil2;
							break;
						case '/' :
							hasil=bil1/bil2;
							break;
						case '^' :
							hasil=(int)pow((double)bil1,(double)bil2);
							break;	
					}
					//printf("hasil=%d",hasil);
					//printf("%d\n",bil1);
					//printf("%d\n",bil2);
					printf("%d %c %d\n",bil1,CToken.tkn,bil2);
					printf("%d\n",hasil);
					Push(&tampung,hasil);
				}
				ADVTOKEN();
		}
		Pop(&tampung,&hasil);
		printf("Hasil=%d\n",hasil);
	}else{
		printf("Ekspresi kosong\n");
	}
	
	
	
	return 0;
}
